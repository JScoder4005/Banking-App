import React from 'react';

const PaymentTransfer = () => {
  return <div></div>;
};

export default PaymentTransfer;
