import React from 'react';

const TransactionHistory = () => {
  return <div></div>;
};

export default TransactionHistory;
