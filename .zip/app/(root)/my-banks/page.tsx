import React from 'react';

const MyBanks = () => {
  return <div></div>;
};

export default MyBanks;
